from django.contrib import admin

# Register your models here.
from .models import Discord_Apps_List
admin.site.register(Discord_Apps_List)
